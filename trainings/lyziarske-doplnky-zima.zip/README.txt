EXI Academy – Lyžiarske doplnky
Verzia 12 – doplnená kapitola Lyžiarske rukavice.
Kapitola obsahuje typy rukavíc, konštrukciu, membrány a izoláciu, meranie obvodu ruky, kontrolu správneho fitu, vybrané modely z ponuky EXIsport a predajné tipy.
Všetky ilustrácie sú lokálne SVG a školenie funguje offline. Odkazy na produktové stránky EXIsport vyžadujú internet. Ilustrácie pri modeloch sú schematické, nie originálne produktové fotografie.

V14: Zmensene produktove obrazky lyziarskych prilieb na polovicu povodnych pixelov a upravene ich zobrazenie. Technologie okuliarov zostali nezmenene; na mobile sa karty zobrazuju pod sebou.
