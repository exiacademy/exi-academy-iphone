EXI Academy – Polarizácia okuliarov

Obsah balíka:
- index.html: responzívne školenie s úvodnou obrazovkou, kartami kapitol, horným prepínačom, späť/ďalej a záverečným testom.
- metadata.json: jedinečný identifikátor školenia, názov a kapitoly.
- assets/: obrázky extrahované z dodaného PDF a uložené lokálne pre offline použitie.

Obsah školenia vychádza z dodaného PDF. Pred importom do produkcie over categoryId "other" voči skutočným ID kategórií v zdrojovom kóde EXI Academy.
