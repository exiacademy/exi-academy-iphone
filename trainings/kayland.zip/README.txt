EXI Academy – KAYLAND: turistická obuv a predaj

Obsah ZIP:
- index.html: vizuálne školenie s kapitolami prepínanými cez dlaždice a hornú lištu, predajnými tipmi a záverečným testom.
- metadata.json: identifikátor školenia a kategória.
- assets/: obrázky extrahované z dodaného PDF; obrázky použité v HTML sú lokálne a fungujú offline.

Obsah vychádza z dodaného súboru KAYLAND(1).pdf. Kategórie zahrnuté: Mountaineering, Backpacking, Approach, Advanced Hiking, Hiking, Fast Hiking, Walking. Dokument menuje aj Junior, Go Wild a Classic, ale neposkytuje k nim podrobný opis. Ceny a konkrétne modelové označenia na obrázkoch môžu byť z konkrétneho katalógu a nemusia zodpovedať aktuálnemu stavu predajne.

Pred importom do produkcie over categoryId "summer" voči aktuálnym kategóriám v zdrojovom kóde EXI Academy.

Vizuálna aktualizácia v2: nový úvodný banner Kayland bol vložený lokálne do assets/kayland-hero-banner.png. Obsah kapitol a pôvodné produktové/ilustračné obrázky zostali zachované.

Verzia 3: produktové prehľady v kategóriách Backpacking, Approach, Advanced Hiking, Hiking, Fast Hiking a Walking sú rozdelené na samostatné čitateľné produktové karty. Použité sú pôvodné produktové obrázky zo školenia; obsah kapitol a pôvodné ID/kategória zostali zachované.
