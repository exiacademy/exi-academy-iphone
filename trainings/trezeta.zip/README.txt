EXI Academy – TREZETA – turistická obuv

Obsah balíka:
- index.html: responzívne školenie s úvodnou obrazovkou, kartami kapitol, horným prepínačom, späť/ďalej a záverečným testom.
- metadata.json: jedinečný identifikátor školenia, názov a kapitoly.
- assets/: obrázky extrahované z dodaného PDF a uložené lokálne pre offline použitie.

Obsah školenia vychádza z dodaného PDF. Pred importom do produkcie over categoryId "summer" voči skutočným ID kategórií v zdrojovom kóde EXI Academy.

Verzia 2: vizuál bol upravený do tmavomodrého štýlu s cyan a oranžovými akcentmi. Použitý je dodaný banner Trezeta a výber kapitol je zmenšený na kompaktné karty. Obsah školenia a pôvodné identifikátory zostali zachované.
