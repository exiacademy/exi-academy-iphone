EXI Academy – Kolobežky

Obsah ZIP: index.html, metadata.json a priečinok images/ s obrázkami z dodaného dokumentu Kolobežky.docx.
Školenie funguje offline, ak aplikácia zachová celý obsah ZIP pri importe.
Import: použi existujúcu funkciu importu ZIP školenia v EXI Academy.
Zdroj obsahu a ilustrácií: dodaný dokument Kolobežky.docx, publikovaný 08.04.2025.
