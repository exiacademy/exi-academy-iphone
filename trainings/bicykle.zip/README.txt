EXI Academy – Bicykle: Foto+

Upravené podľa pripomienok:
- Konštrukcia bicykla používa dodaný obrázok s popismi jednotlivých dielov.
- Brzdy majú samostatné fotografie podľa typu (V-brzda a kotúčová brzda); tieto fotografie sú načítavané z externých obrazových adries, takže pri ich zobrazení treba internet.
- Fotografie vidlíc sú zmenšené a umiestnené pri príslušných popisoch.
- Úvodná sekcia značiek obsahuje fotografie; Amulet je zobrazený vlastným bicyklom z dodaného dokumentu.
- Odstránené sú klikateľné odkazy na webové stránky.
- Zvyšok školenia, kalkulačka a test ostávajú zachované.

Importuj ZIP cez existujúci importér EXI Academy. Pred nasadením over categoryId voči aktuálnym ID kategórií v zdrojovom kóde aplikácie.


Doplnenie verzie Foto+ v2:
- Obrázky bŕzd sú teraz uložené lokálne v assets/v-brake-local.jpg a assets/disc-brake-local.jpg.
- Ide o AI-vytvorené realistické ilustračné detailné zábery, nie fotografie konkrétneho produktu.
- Obrázky bŕzd sa zobrazujú bez internetu.
- Externé obrázkové URL v HTML boli odstránené alebo nahradené lokálnymi obrázkami.
