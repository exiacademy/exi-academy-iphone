EXI Academy – TECNICA – outdoorová obuv
Verzia: 19

Obsah ZIP archívu:
- index.html – offline školenie
- metadata.json – identifikácia školenia a kapitoly

Aktualizácia v19: Kapitola 5 doplnená o dramatickú grafiku MAGMA. Kapitola 7 obsahuje samostatné infografiky modelov SULFUR, MAKALU a SPARK. Kapitola 8 rozšírená o starostlivosť o koženú a textilnú obuv, odporúčané doplnkové produkty a predajné tipy. Kapitola 9 obsahuje funkčný záverečný test s automatickým vyhodnotením.

Všetky obrázky sú vložené priamo v HTML (base64). Školenie nevyžaduje internet ani externé knižnice a je optimalizované pre mobilné zobrazenie.
