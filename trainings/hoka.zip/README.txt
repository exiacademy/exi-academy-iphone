EXI Academy – HOKA: základy pre predajcu

Obsah:
- index.html: responzívne offline školenie v slovenčine, kapitoly, predajné tipy a záverečný test
- metadata.json: identifikátor školenia a kategória
- assets/: obrázky extrahované z dodaného HOKA.pdf, uložené priamo v ZIP-e

Offline:
Všetky obrázky použité v HTML sú lokálne v assets/. HTML neobsahuje externé obrázkové URL ani odkazy na webové stránky.

Poznámka:
Obsah modelov a technológií vychádza z dodaného PDF. Pri konkrétnych modeloch treba v predajni overiť aktuálny modelový rok a špecifikáciu. categoryId je nastavené na "summer" ako pracovné zaradenie obuvi; pred ostrým importom ho over voči aktuálnym ID kategórií v zdrojovom kóde aplikácie.

Import:
Použi existujúci ZIP importer v EXI Academy; importer nebol menený.


Vizuálna verzia:
- HOKA školenie používa teraz prepínateľné kapitoly/taby: kliknutím sa kapitola vymení, namiesto dlhého posúvania celej stránky.
- Pridaný je ukazovateľ postupu a tlačidlá Späť/Ďalej.
- Zmenené je pozadie aj farebná paleta na tmavomodro-fialovú s tyrkysovými a fialovými akcentmi.
- Obsah a lokálne obrázky ostávajú v balíku; nie sú pridané webové odkazy.


Vizuálne vylepšenie:
- Štýl upravený podľa dodaného referenčného obrázka: tmavomodré pozadie, žiarivé tyrkysové nadpisy, oranžové akcenty, výrazné karty a väčšie produktové fotografie.
- Pridaná dlaždicová navigácia na začiatku; kliknutie na dlaždicu aj hornú lištu prepína obsah kapitoly.
- Všetky obrázky školenia sú lokálne v assets/ a nevyžadujú internet.

Aktualizácia v2: nový úvodný banner, vizuál v živších HOKA farbách, rozšírená kapitola modelov o Rincon a produktovo zobrazené aktuálnejšie generácie.

Aktualizácia v3: produktové fotografie modelov Clifton 11, Bondi 9, Arahi 9, Mach 7, Gaviota 6, Speedgoat 7, Challenger 8 a Rincon boli nahradené dodanými obrázkami. Všetky fotografie sú uložené lokálne v ZIP.
