EXI Academy – Inline korčule FILA v3

ZIP obsahuje index.html, metadata.json a lokálne obrázky. Opravené rozlíšenie rýchlostných korčúľ (schematická ilustrácia s nízkou topánkou, dlhým rámom a veľkými kolieskami) a inline hokeja (samostatné fotografie Bauer/SULOV). Pridaná kapitola Doplnky a ochrana s prilbou, chráničmi kolien/lakťov a zápästí.

Dôležité: sieťové sťahovanie fotografií z webu nebolo v prostredí tvorby dostupné. Preto sú nové obrázky ochranných pomôcok offline vektorové ilustrácie, nie vydávané za stiahnuté produktové fotografie. Zdroje na overenie sú uvedené v HTML.
