EXI Academy — Ošetrovacie prípravky
Verzia ZIP: 5
Názov: Ošetrovacie prípravky
ID / trainingId: exi-osetrovacie-pripravky-2026-v3
categoryId: other

Obsah balíka
- index.html: kompletné interaktívne školenie
- metadata.json: identifikátory a sedem kapitol
- assets/: lokálne obrázky konkrétnych produktov, vyrezané z obrázkov priradených ku konkrétnym názvom v dodanom dokumente Ošetrovacie pripravky.docx

Funkcie
- kapitoly v štýle KAYLAND so štruktúrou menu, hornými kartami, indikátorom postupu a navigáciou Späť/Ďalej
- interaktívny výber pracieho prípravku
- prepínač spôsobu impregnácie: praním / sprejom
- interaktívne predajné situácie
- záverečný test s vysvetleniami odpovedí a možnosťou opakovania
- obrázky a skripty sú lokálne; základné školenie nevyžaduje internet

Podklad
Primárny zdroj: Ošetrovacie pripravky.docx dodaný používateľom. Názvy produktov a základné postupy zodpovedajú zdroju.
Niektoré doplňujúce texty pre Feldten, Merino, EMPIRE Clean Keeper a Fresh Express vychádzajú z produktových stránok EXIsport:
https://www.exisport.com/sk/14201-osetrovacie-pripravky-na-textil
https://www.exisport.com/sk/14159-osetrovacie-pripravky-na-obuv/znacka-empire

Poznámka: vždy majú prednosť aktuálne pokyny na etikete výrobku a na štítku ošetrovaného materiálu. ZIP prešiel kontrolou integrity; import musí byť potvrdený v EXI Academy.
