EXI Academy — LOPTOVÉ ŠPORTY – interné školenie (verzia 4)

Obsah balíka:
- index.html: offline školenie (8 kapitol)
- metadata.json: zachované ID a categoryId
- assets/: lokálne fotografické referenčné ukážky, dostupné offline

ID: exi-loptove-sporty-2026-v1
categoryId: other
Verzia: 3

Pri dostupnom internete sa školenie pokúsi načítať originálne produktové fotografie zo zdrojových stránok. Ak sa stiahnutie nepodarí alebo je zariadenie offline, použije sa lokálna fotografická referenčná ukážka. Lokálne fotografie sú realistické typové referencie, nie presné obrázky konkrétnych značkových modelov stiahnuté do ZIP-u. Nie sú označované ako oficiálne fotografie produktov. Pri predaji over skutočný výrobok, štítok a technický list.

Oficiálne zdroje technických údajov a produktové odkazy sú uvedené v školení. Pred nasadením otestuj import do EXI Academy.


Verzia 4: odstránené opakované obrázky, upravené veľkostné karty, spojené kapitoly volejbal/Mikasa a navigácia posúva na nadpis kapitoly.
