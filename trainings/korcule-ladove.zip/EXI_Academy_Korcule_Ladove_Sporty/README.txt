EXI Academy – Korčule na ľad a hokej
Verzia: 25

Importujte ZIP cez ZIP importer v aplikácii EXI Academy.
Školenie obsahuje offline HTML, vložené obrázky, kapitolu brúsenie a údržba a záverečný kvíz.
