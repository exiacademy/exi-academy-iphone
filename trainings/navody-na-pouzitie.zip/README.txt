EXI Academy – Návody na použitie pri predaji tovaru

Offline školenie vytvorené zo súboru „Navody na pouzitie.docx“.

Obsah ZIP:
- index.html: interaktívne školenie
- metadata.json: metadáta školenia pre EXI Academy
- assets/: obrázky vybraté z obrázkov vložených do zdrojového DOCX

Identifikátory:
- id / trainingId: exi-navody-na-pouzitie-2026-v3 (zachované)
- categoryId: other (zachované)

Poznámka: zdrojový dokument je označený dátumom 15.01.2020. Právne odkazy a pravidlá, ktoré sa mohli časom zmeniť, sú v školení označené ako obsah zdrojového dokumentu; aktuálny pracovný postup treba overiť u SM.

Mobilná navigácia – oprava v5: prepnutie kapitoly prescrolluje na nadpis novej kapitoly namiesto návratu na úvodný hero blok.
